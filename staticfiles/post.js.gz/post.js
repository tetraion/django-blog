(function($) {
    $(document).ready(function() {
      alert("JSが読み込まれました。")
    });
  })(django.jQuery || jQuery);
  